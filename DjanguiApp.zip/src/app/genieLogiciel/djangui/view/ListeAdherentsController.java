/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.genieLogiciel.djangui.view;

import io.datafx.controller.FXMLController;
import javax.annotation.PostConstruct;

/**
 * FXML Controller class
 *
 * @author kevinash
 */
@FXMLController("listeAdherents.fxml")
public class ListeAdherentsController {

    @PostConstruct
    public void init() {

    }

}
